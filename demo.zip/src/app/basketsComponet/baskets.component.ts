import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'baskets',
  templateUrl: './baskets.component.html',
  styleUrls: ['./baskets.component.css']
})
export class BasketsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
